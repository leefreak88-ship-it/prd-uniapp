/*
 * @Author: zhihao li leefreak88@gmail.com
 * @Date: 2026-03-31 21:23:58
 * @LastEditors: zhihao li leefreak88@gmail.com
 * @LastEditTime: 2026-04-02 16:44:26
 * @FilePath: \pd_uniapp\src\main.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import * as Pinia from "pinia";
import { QueryClient, VueQueryPlugin } from "@tanstack/vue-query";
import { createSSRApp } from "vue";
import App from "./App.vue";

export function createApp() {
  const app = createSSRApp(App);
  const queryClient = new QueryClient();
  app.use(Pinia.createPinia());
  app.use(VueQueryPlugin, { queryClient });
  return {
    app,
    Pinia,
  };
}
