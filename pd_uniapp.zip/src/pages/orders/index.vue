<script setup lang="ts">
import { computed } from "vue";
import { useShop } from "@/hooks/use-shop";

const { orders, isLogin, confirmPay, initShop } = useShop();

const orderList = computed(() => orders.value);

const formatTime = (time: string) => new Date(time).toLocaleString();

const handlePay = async (orderId: string) => {
  try {
    await confirmPay(orderId);
    uni.showToast({
      title: "已支付并生成账单",
      icon: "none",
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "支付失败";
    uni.showToast({
      title: message,
      icon: "none",
    });
  }
};

const gotoLogin = () => {
  uni.navigateTo({
    url: "/pages/login/index",
  });
};

initShop();
</script>

<template>
  <view class="page">
    <view v-if="!isLogin" class="login-card">
      <text class="login-title">请先登录后查看订单</text>
      <wd-button type="primary" @click="gotoLogin">
        去登录
      </wd-button>
    </view>
    <view v-else-if="orderList.length === 0" class="empty">暂无订单，去首页选购吧</view>
    <view v-else class="list">
      <view v-for="item in orderList" :key="item.id" class="card">
        <view class="row">
          <text class="name">{{ item.productName }}</text>
          <wd-tag :type="item.status === 'paid' ? 'success' : 'warning'">
            {{ item.status === "paid" ? "已支付" : "待支付" }}
          </wd-tag>
        </view>
        <text class="line">订单号：{{ item.id }}</text>
        <text class="line">下单时间：{{ formatTime(item.createdAt) }}</text>
        <text v-if="item.paidAt" class="line">支付时间：{{ formatTime(item.paidAt) }}</text>
        <view class="bottom">
          <text class="amount">¥{{ item.amount }}</text>
          <wd-button
            v-if="item.status === 'unpaid'"
            type="primary"
            size="small"
            @click="handlePay(item.id)"
          >
            去支付
          </wd-button>
        </view>
      </view>
    </view>
  </view>
</template>

<style scoped lang="scss">
.page {
  padding: 24rpx;
}

.empty {
  margin-top: 200rpx;
  text-align: center;
  color: #8b949e;
}

.login-card {
  margin-top: 200rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20rpx;
}

.login-title {
  color: #646a73;
}

.list {
  display: flex;
  flex-direction: column;
  gap: 18rpx;
}

.card {
  background: #fff;
  border-radius: 18rpx;
  padding: 24rpx;
}

.row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12rpx;
}

.name {
  font-size: 30rpx;
  font-weight: 600;
}

.line {
  display: block;
  color: #646a73;
  margin-top: 8rpx;
  font-size: 24rpx;
}

.bottom {
  margin-top: 18rpx;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.amount {
  color: #ee0a24;
  font-size: 34rpx;
  font-weight: 700;
}
</style>
