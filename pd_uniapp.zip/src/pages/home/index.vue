<script setup lang="ts">
import { onLoad, onShow } from "@dcloudio/uni-app";
import { computed, ref } from "vue";
import ProductCard from "@/components/ProductCard.vue";
import { useShop } from "@/hooks/use-shop";
import { useAuthStore } from "@/stores/auth";
import type { Product } from "@/api/types";

const {
  categories,
  products,
  activeCategoryId,
  user,
  isLogin,
  initShop,
  loadHomeData,
  setActiveCategory,
  submitOrder,
  confirmPay,
  hasPurchased,
} = useShop();

const homeRequesting = ref(false);
const homeLoaded = ref(false);
const payPopupVisible = ref(false);
const currentOrderId = ref("");
const currentProduct = ref<Product | null>(null);

const categoryList = computed(() => categories.value);
const productList = computed(() => products.value);

const handleSelectCategory = (categoryId: string) => {
  setActiveCategory(categoryId);
};

const handleHomeLifecycle = async (trigger: "onLoad" | "onShow") => {
  if (homeRequesting.value || (trigger === "onShow" && homeLoaded.value)) {
    return;
  }
  homeRequesting.value = true;
  const startAt = Date.now();
  console.warn(`[home] lifecycle: ${trigger}`);
  try {
    await loadHomeData();
    homeLoaded.value = true;
    console.warn(`[home] index-api: ${Date.now() - startAt}ms`);
  } catch (error) {
    console.warn(`[home] index-api failed: ${Date.now() - startAt}ms`);
    const message = error instanceof Error ? error.message : "首页数据加载失败";
    uni.showToast({
      title: message,
      icon: "none",
    });
  } finally {
    homeRequesting.value = false;
  }
};

const handleBuy = async (productId: string) => {
  const target = productList.value.find((item) => item.id === productId) ?? null;
  if (!target) {
    return;
  }
  try {
    const order = await submitOrder(productId);
    currentOrderId.value = order.id;
    currentProduct.value = target;
    payPopupVisible.value = true;
  } catch (error) {
    const message = error instanceof Error ? error.message : "下单失败";
    uni.showToast({
      title: message,
      icon: "none",
    });
    if (!isLogin.value) {
      uni.navigateTo({
        url: "/pages/login/index",
      });
    }
  }
};

const handlePaySuccess = async () => {
  if (!currentOrderId.value) {
    return;
  }
  try {
    await confirmPay(currentOrderId.value);
  } catch (error) {
    const message = error instanceof Error ? error.message : "支付失败";
    uni.showToast({
      title: message,
      icon: "none",
    });
    return;
  }
  payPopupVisible.value = false;
  uni.showToast({
    title: "支付成功，账单已生成",
    icon: "none",
  });
  currentOrderId.value = "";
  currentProduct.value = null;
};

const handleGotoLogin = () => {
  uni.navigateTo({
    url: "/pages/login/index",
  });
};

const handleLogout = () => {
  const authStore = useAuthStore();
  authStore.logout();
  uni.showToast({
    title: "已退出登录",
    icon: "none",
  });
};

onLoad(() => {
  initShop();
  void handleHomeLifecycle("onLoad");
});

onShow(() => {
  void handleHomeLifecycle("onShow");
});
</script>

<template>
  <view class="page">
    <view class="layout">
      <scroll-view scroll-y class="category-panel">
        <view
          v-for="item in categoryList"
          :key="item.id"
          class="category-item"
          :class="{ active: item.id === activeCategoryId }"
          @click="handleSelectCategory(item.id)"
        >
          {{ item.name }}
        </view>
      </scroll-view>

      <scroll-view scroll-y class="product-panel">
        <view class="header">
          <view class="header-top">
            <text class="title">商品列表</text>
            <wd-button
              v-if="isLogin"
              plain
              size="small"
              type="warning"
              @click="handleLogout"
            >
              退出登录
            </wd-button>
            <wd-button v-else plain size="small" type="primary" @click="handleGotoLogin">
              登录
            </wd-button>
          </view>
          <wd-tag v-if="isLogin" type="success">当前用户：{{ user?.nickname }}</wd-tag>
          <wd-tag v-else type="warning">未登录，仅可浏览商品</wd-tag>
          <wd-tag type="primary">购买成功后可在账单页核验</wd-tag>
        </view>
        <view class="product-list">
          <ProductCard
            v-for="item in productList"
            :key="item.id"
            :product="item"
            :purchased="hasPurchased(item.id)"
            @buy="handleBuy"
          />
        </view>
      </scroll-view>
    </view>

    <wd-popup v-model="payPopupVisible" position="bottom">
      <view class="pay-popup">
        <text class="popup-title">确认支付</text>
        <text v-if="currentProduct" class="popup-text">
          商品：{{ currentProduct.name }}，金额：¥{{ currentProduct.price }}
        </text>
        <view class="popup-actions">
          <wd-button plain @click="payPopupVisible = false">稍后支付</wd-button>
          <wd-button type="primary" @click="handlePaySuccess">支付成功</wd-button>
        </view>
      </view>
    </wd-popup>
  </view>
</template>

<style scoped lang="scss">
.page {
  height: calc(100vh - var(--window-top));
}

.layout {
  display: flex;
  height: 100%;
}

.category-panel {
  width: 200rpx;
  height: 100%;
  background: #ffffff;
  border-right: 1rpx solid #ebeef5;
}

.category-item {
  padding: 28rpx 16rpx;
  text-align: center;
  color: #646a73;
  font-size: 26rpx;
}

.category-item.active {
  color: #1989fa;
  font-weight: 600;
  background: #f0f7ff;
}

.product-panel {
  flex: 1;
  height: 100%;
  padding: 24rpx;
}

.header {
  display: flex;
  flex-direction: column;
  gap: 14rpx;
  margin-bottom: 20rpx;
}

.header-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.title {
  font-size: 34rpx;
  font-weight: 700;
}

.product-list {
  display: flex;
  flex-direction: column;
  gap: 18rpx;
  padding-bottom: 40rpx;
}

.pay-popup {
  padding: 36rpx 28rpx 40rpx;
  background: #fff;
  border-radius: 24rpx 24rpx 0 0;
}

.popup-title {
  display: block;
  font-size: 32rpx;
  font-weight: 700;
  margin-bottom: 16rpx;
}

.popup-text {
  color: #646a73;
  font-size: 26rpx;
}

.popup-actions {
  margin-top: 28rpx;
  display: flex;
  gap: 16rpx;
  justify-content: flex-end;
}
</style>
