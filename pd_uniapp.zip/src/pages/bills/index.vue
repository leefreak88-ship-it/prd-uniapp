<script setup lang="ts">
import { computed } from "vue";
import { useShop } from "@/hooks/use-shop";

const { bills, orders, isLogin, initShop } = useShop();

const billList = computed(() => bills.value);

const orderMap = computed(() => {
  return orders.value.reduce<Record<string, string>>((acc, item) => {
    acc[item.id] = item.productName;
    return acc;
  }, {});
});

const formatTime = (time: string) => new Date(time).toLocaleString();

const gotoLogin = () => {
  uni.navigateTo({
    url: "/pages/login/index",
  });
};

initShop();
</script>

<template>
  <view class="page">
    <view class="tips">账单可作为已购买凭证，关联订单用于核验客户是否已完成支付。</view>
    <view v-if="!isLogin" class="login-card">
      <text class="login-title">请先登录后查看账单</text>
      <wd-button type="primary" @click="gotoLogin">
        去登录
      </wd-button>
    </view>
    <view v-else-if="billList.length === 0" class="empty">暂无账单</view>
    <view v-else class="list">
      <view v-for="item in billList" :key="item.id" class="card">
        <view class="row">
          <text class="title">账单号：{{ item.id }}</text>
          <wd-tag type="success">已入账</wd-tag>
        </view>
        <text class="line">订单号：{{ item.orderId }}</text>
        <text class="line">商品：{{ orderMap[item.orderId] || "未知商品" }}</text>
        <text class="line">账单时间：{{ formatTime(item.createdAt) }}</text>
        <text class="amount">¥{{ item.amount }}</text>
      </view>
    </view>
  </view>
</template>

<style scoped lang="scss">
.page {
  padding: 24rpx;
}

.tips {
  background: #e8f3ff;
  color: #1864ab;
  padding: 20rpx;
  border-radius: 16rpx;
  font-size: 24rpx;
  margin-bottom: 20rpx;
}

.empty {
  margin-top: 180rpx;
  text-align: center;
  color: #8b949e;
}

.login-card {
  margin-top: 180rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20rpx;
}

.login-title {
  color: #646a73;
}

.list {
  display: flex;
  flex-direction: column;
  gap: 18rpx;
}

.card {
  background: #fff;
  border-radius: 18rpx;
  padding: 24rpx;
}

.row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12rpx;
}

.title {
  font-size: 28rpx;
  font-weight: 600;
}

.line {
  display: block;
  color: #646a73;
  margin-top: 8rpx;
  font-size: 24rpx;
}

.amount {
  display: block;
  margin-top: 14rpx;
  color: #ee0a24;
  font-size: 34rpx;
  font-weight: 700;
}
</style>
