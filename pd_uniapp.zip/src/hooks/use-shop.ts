import { useMutation, useQuery, useQueryClient } from "@tanstack/vue-query";
import { storeToRefs } from "pinia";
import { computed, watch } from "vue";
import { getCategories, getProducts } from "@/api/goods";
import { billApi } from "@/api/bills";
import { createOrder, orderApi, payOrder } from "@/api/order";
import type { Bill, Order, Product } from "@/api/types";
import { useAuthStore } from "@/stores/auth";
import { useShopStore } from "@/stores/shop";

export const useShop = () => {
  const queryClient = useQueryClient();
  const authStore = useAuthStore();
  authStore.restoreState();
  const shopStore = useShopStore();
  const { activeCategoryId } = storeToRefs(shopStore);
  const { user } = storeToRefs(authStore);
  const currentCategoryId = computed(() => activeCategoryId.value || "all");
  const currentUserId = computed(() => user.value?.id || "");

  const categoriesQuery = useQuery({
    queryKey: ["shop", "categories"],
    queryFn: getCategories,
  });
  const allProductsQuery = useQuery({
    queryKey: ["shop", "products", "all"],
    queryFn: () => getProducts(),
  });
  const productsQuery = useQuery({
    queryKey: computed(() => ["shop", "products", currentCategoryId.value]),
    queryFn: () => getProducts(activeCategoryId.value || undefined),
  });
  const ordersQuery = useQuery({
    queryKey: computed(() => ["shop", "orders", currentUserId.value]),
    queryFn: () =>
      orderApi.orderList({
        pagination: {
          current: 1,
          pageSize: 100,
        },
      }),
    enabled: computed(() => Boolean(user.value?.id)),
  });
  const billsQuery = useQuery({
    queryKey: computed(() => ["shop", "bills", currentUserId.value]),
    queryFn: () =>
      billApi.billList({
        pagination: {
          current: 1,
          pageSize: 100,
        },
      }),
    enabled: computed(() => Boolean(user.value?.id)),
  });

  const categories = computed(() => categoriesQuery.data.value ?? []);
  const products = computed(() => productsQuery.data.value ?? []);
  const productMap = computed(() => {
    return (allProductsQuery.data.value ?? []).reduce<Record<string, Product>>((acc, item) => {
      acc[item.id] = item;
      return acc;
    }, {});
  });
  const remoteOrders = computed<Order[]>(() => {
    const list = ordersQuery.data.value?.result ?? [];
    return list.map((item) => ({
      id: item.id || "",
      userId: user.value?.id || "",
      productId: item.goodsId || "",
      productName: productMap.value[item.goodsId || ""]?.name || item.goodsId || "未知商品",
      amount: item.orderPrice ? item.orderPrice / 100 : 0,
      status: "paid",
      createdAt:
        item.createTime instanceof Date
          ? item.createTime.toISOString()
          : item.createTime
            ? new Date(item.createTime).toISOString()
            : new Date().toISOString(),
      paidAt:
        item.updateTime instanceof Date
          ? item.updateTime.toISOString()
          : item.updateTime
            ? new Date(item.updateTime).toISOString()
            : undefined,
    }));
  });
  const remoteBills = computed<Bill[]>(() => {
    const list = billsQuery.data.value?.result ?? [];
    return list.map((item) => ({
      id: item.id || "",
      userId: user.value?.id || "",
      orderId: item.orderId || "",
      amount: item.orderInfo?.orderPrice ? item.orderInfo.orderPrice / 100 : 0,
      createdAt:
        item.createTime instanceof Date
          ? item.createTime.toISOString()
          : item.createTime
            ? new Date(item.createTime).toISOString()
            : new Date().toISOString(),
    }));
  });
  const orderList = computed<Order[]>(() => {
    if (!user.value) {
      return [];
    }
    const localList = shopStore.getOrdersByUser(user.value.id);
    const merged = new Map<string, Order>();
    remoteOrders.value.forEach((item) => {
      merged.set(item.id, item);
    });
    localList.forEach((item) => {
      merged.set(item.id, item);
    });
    return Array.from(merged.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  });
  const billList = computed<Bill[]>(() => {
    if (!user.value) {
      return [];
    }
    const localList = shopStore.getBillsByUser(user.value.id);
    const merged = new Map<string, Bill>();
    remoteBills.value.forEach((item) => {
      merged.set(item.id, item);
    });
    localList.forEach((item) => {
      merged.set(item.id, item);
    });
    return Array.from(merged.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  });
  const paidCount = computed(() => orderList.value.filter((item) => item.status === "paid").length);

  watch(
    categories,
    (value) => {
      const firstCategory = value[0];
      if (firstCategory && !activeCategoryId.value) {
        shopStore.setActiveCategory(firstCategory.id);
      }
    },
    { immediate: true },
  );

  const loadHomeData = async () => {
    const categoriesResult = await categoriesQuery.refetch();
    const nextCategories = categoriesResult.data ?? [];
    const firstCategory = nextCategories[0];
    if (firstCategory && !activeCategoryId.value) {
      shopStore.setActiveCategory(firstCategory.id);
    }
    await allProductsQuery.refetch();
    await productsQuery.refetch();
  };

  const submitOrderMutation = useMutation({
    mutationFn: async (productId: string) => {
      if (!user.value) {
        throw new Error("请先登录");
      }
      return createOrder(productId, user.value.id);
    },
    onSuccess: (order) => {
      shopStore.orders.unshift(order);
      shopStore.saveState();
    },
  });
  const confirmPayMutation = useMutation({
    mutationFn: async (orderId: string) => {
      if (!user.value) {
        throw new Error("请先登录");
      }
      const target = shopStore.orders.find((item) => item.id === orderId);
      if (!target || target.status === "paid" || target.userId !== user.value.id) {
        return;
      }
      const { paidOrder, bill } = await payOrder(target);
      shopStore.orders = shopStore.orders.map((item) => (item.id === orderId ? paidOrder : item));
      shopStore.bills.unshift(bill);
      shopStore.saveState();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["shop"] });
    },
  });

  const submitOrder = (productId: string) => submitOrderMutation.mutateAsync(productId);
  const confirmPay = (orderId: string) => confirmPayMutation.mutateAsync(orderId);
  const hasPurchased = (productId: string) => {
    if (!user.value) {
      return false;
    }
    return orderList.value.some((item) => item.productId === productId && item.status === "paid");
  };

  return {
    categories,
    products,
    orders: orderList,
    bills: billList,
    activeCategoryId,
    paidCount,
    user,
    isLogin: computed(() => authStore.isLogin),
    initShop: shopStore.initShop,
    loadHomeData,
    setActiveCategory: shopStore.setActiveCategory,
    submitOrder,
    confirmPay,
    hasPurchased,
  };
};
