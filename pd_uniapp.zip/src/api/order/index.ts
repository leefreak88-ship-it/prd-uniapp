/*
 * @Author: zhihao li leefreak88@gmail.com
 * @Date: 2026-04-02 21:49:58
 * @LastEditors: zhihao li leefreak88@gmail.com
 * @LastEditTime: 2026-04-02 21:59:01
 * @FilePath: \pd_uniapp\src\api\order\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import http from "@/utils/request";
import { getProductById } from "@/api/goods";
import type { Bill, Order } from "@/api/types";
import type { OrderDto, OrderRequestPayload } from "./types";
import type { PaginationResp } from "../types";

export const orderApi = {
  orderList: async (payload: OrderRequestPayload): Promise<PaginationResp<OrderDto>> => {
    return http.post("/app/order/page", payload);
  },
};

const createOrderId = () => `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
const createBillId = () => `BILL-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

export const createOrder = async (productId: string, userId: string): Promise<Order> => {
  const product = await getProductById(productId);
  return {
    id: createOrderId(),
    userId,
    productId: product.id,
    productName: product.name,
    amount: product.price,
    status: "unpaid",
    createdAt: new Date().toISOString(),
  };
};

export const payOrder = async (order: Order): Promise<{ paidOrder: Order; bill: Bill }> => {
  const paidOrder: Order = {
    ...order,
    status: "paid",
    paidAt: new Date().toISOString(),
  };
  const bill: Bill = {
    id: createBillId(),
    userId: order.userId,
    orderId: order.id,
    amount: order.amount,
    createdAt: new Date().toISOString(),
  };
  return {
    paidOrder,
    bill,
  };
};
