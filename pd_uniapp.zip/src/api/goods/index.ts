/*
 * @Author: zhihao li leefreak88@gmail.com
 * @Date: 2026-04-02 21:49:58
 * @LastEditors: zhihao li leefreak88@gmail.com
 * @LastEditTime: 2026-04-03 18:37:25
 * @FilePath: \pd_uniapp\src\api\bills\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import http from "@/utils/request";
import type { ProductListReq, ProductListResp } from "./types";
import { categoryApi } from "@/api/category";
import type { Category, Product } from "@/api/types";
import type { PaginationResp } from "../types";

export const goodsApi = {
  productList: async (payload: ProductListReq): Promise<PaginationResp<ProductListResp>> => {
    return http.post("/app/goodsInfo/page", payload);
  },
};

const mapProduct = (item: ProductListResp): Product => {
  return {
    id: item.id || "",
    categoryId: item.goodsTypeId || "",
    name: item.goodsName || "",
    price: item.goodsPrice ?? 0,
    desc: item.goodsName || "",
    stock: 0,
    image: item.goodsImage || "",
  };
};

export const getCategories = async (): Promise<Category[]> => {
  const response = await categoryApi.categoryList({});
  const list = response.result ?? [];
  return list.map((item) => ({
    id: item.id || "",
    name: item.goodsTypeName || "",
  }));
};

export const getProducts = async (categoryId?: string): Promise<Product[]> => {
  const payload: ProductListReq = {
    pageType: categoryId ? "goods_type_id" : undefined,
    params: categoryId ? { goodsTypeId: categoryId } : undefined,
  };
  const response = await goodsApi.productList(payload);
  const list = response.result ?? [];
  return list.map(mapProduct);
};

export const getProductById = async (productId: string): Promise<Product> => {
  const all = await getProducts();
  const target = all.find((item) => item.id === productId);
  if (!target) {
    throw new TypeError("商品不存在");
  }
  return target;
};
