import uniHelper from '@uni-helper/eslint-config'

export default uniHelper(
  {},
  {
    rules: {
      'antfu/top-level-function': 'off',
      'jsonc/sort-keys': 'off',
      'perfectionist/sort-imports': 'off',
      'style/arrow-parens': 'off',
      'style/brace-style': 'off',
      'style/member-delimiter-style': 'off',
      'style/quotes': 'off',
      'style/semi': 'off',
      'vue/singleline-html-element-content-newline': 'off',
    },
  },
)
